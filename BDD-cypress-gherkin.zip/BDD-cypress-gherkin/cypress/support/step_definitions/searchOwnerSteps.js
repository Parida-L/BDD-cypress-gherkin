import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import  MainPage  from "../../pages/MainPage.js";
import  FindOwners  from "../../pages/FindOwners.js";

const mainPage = new MainPage();
const findOwners = new FindOwners();

Given("I am on the Find Owners page", () => {
  findOwners.visit();
  findOwners.verifyUrl();
});
When("I search the owner {string}", (lastName) => {
  findOwners.visit();
  findOwners.verifyUrl();
});

