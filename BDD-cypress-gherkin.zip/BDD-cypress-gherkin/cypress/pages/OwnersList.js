class OwnersList {
    //Centralisation des sélecteurs 
    selectors = {
        titlePage: '#owners', //Owners 
        ownersTable: '#ownersTable', //tableau
        tableHead: '//*[@id="ownersTable"]/thead', //table head 
    }

    //Méthodes pour intéragir avec les éléments 
    getTitlePage(){
        return cy.get(this.selectors.titlePage)
    }
    getOwnersTable(){
        return cy.get(this.selectors.ownersTable)
    }
    getTableHead(){
        return cy.get(this.selectors.tableHead)
    }
 
    searchOwner(lastName) {
        cy.this.selectors.lastNameForm.type(lastName);
        cy.this.selectors.searchButton.click();
    }

    visit(){
        cy.visit('/owners?lastName=')
    }

    verifyUrl(){
        cy.url().should("contain", "/owners?lastName=")
    }

    verifyTitle(title){
        cy.get(this.selectors.titlePage).should('contain.text', title)
    }

}

export default OwnersList;