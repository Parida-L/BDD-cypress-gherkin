class FindOwners {
    //Centralisation des sélecteurs 
    selectors = {
        titlePage: 'h2',
        lastNameForm: '#lastName',
        formTitle: '.control-label',
        searchButton: '[type="submit"]',
        addNewOnwerButton: 'a.btn'
        
    }

    //Méthodes pour intéragir avec les éléments 
    getTitlePage(){
        return cy.get(this.selectors.titlePage)
    }
    getLastNameForm(){
        return cy.get(this.selectors.lastNameForm)
    }
    getFormTitle(){
        return cy.get(this.selectors.formTitle)
    }
    getSearchButton(){
        return cy.get(this.selectors.searchButton)
    }
    getAddNewOnwerButton(){
        return cy.get(this.selectors.addNewOnwerButton)
    }

    searchOwner(lastName) {
        cy.this.selectors.lastNameForm.type(lastName);
        cy.this.selectors.searchButton.click();
    }

    visit(){
        cy.visit('/owners/find')
    }

    verifyTitle(title){
        cy.get(this.selectors.titlePage).should('contain.text', title)
    }

    verifyUrl(){
        cy.url().should("contain", "/owners/find")
    }

}

export default FindOwners;