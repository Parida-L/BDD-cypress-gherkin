class MainPage {

    //Centralisation des sélecteurs 
    selectors = {
      homeButton: 'a[href="/"]',
      findOwnersButton: 'a[href="/owners/find"]',
      vetenariansButton: 'a[href="/vets"]',
      welcomeMessage: 'h2',
      navbar: '.navbar',
      homeImage: '.img-responsive'
    }
  
    //Méthodes pour intéragir avec les éléments 
    getFindOwnersButton(){
      return cy.get(this.selectors.findOwnersButton)
    }
  
    getHomeButton(){
      return cy.get(this.selectors.homeButton)
    }
  
    getVetenariansButton(){
      return cy.get(this.selectors.vetenariansButton)
    }
  
    getWelcomeMessage(){
      return cy.get(this.selectors.welcomeMessage)
    }

    getHomeImage(){
      return cy.get(this.selectors.homeImage)
    }

    getNavbar(){
        return cy.get(this.selectors.navbar)
    }
  
    visit() {
      cy.visit("/");
    }

    verifyWelcomeMessage(message){
      cy.get(this.selectors.welcomeMessage).should("contain.text", message); 
    }
  
    verifyUrl(){
      cy.url().should(
        "eq",
        "https://spring-framework-petclinic-qctjpkmzuq-od.a.run.app/"
      );
    }
  
    verifyNavbar(){
      cy.get(".navbar").should("exist");
      cy.get(".navbar a").should("have.length.at.least", 4).and("be.visible");
      cy.get(".navbar a").contains("Home").click();
    }
  
    verifyPageElements() {
      cy.get(".img-responsive").should("have.attr", "src").and("contain", ".png");
      cy.getWelcomeMessage.should("contain", "Welcome");
      cy.get(".fa-home").should("exist");
    }
  
    navigateToFindOwners() {
      cy.getFindOwnersButton.click();
      cy.get("h2").should("have.text", "Find Owners");
    }
  
    navigateToVeterinarians() {
      cy.getVetenariansButton.click();
      cy.get("h2").should("have.text", "Veterinarians");
    }


}
  
export default MainPage;
  