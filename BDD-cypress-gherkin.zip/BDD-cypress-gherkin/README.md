# BDD-cypress-gherkin

`npm install @badeball/cypress-cucumber-preprocessor`
`npm install @bahmutov/cypress-esbuild-preprocessor`

Arborescence

- features
- fixtures
- pages
- support
  - step_definitions
- cypress.config.ts
